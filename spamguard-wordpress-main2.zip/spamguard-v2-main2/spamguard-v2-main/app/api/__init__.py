"""
API Routes Package
"""

# Importar routers para fácil acceso
from app.api import routes, routes_ml

__all__ = ['routes', 'routes_ml']
